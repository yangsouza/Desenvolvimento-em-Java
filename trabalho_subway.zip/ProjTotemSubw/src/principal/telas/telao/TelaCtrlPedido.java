package principal.telas.telao;

public class TelaCtrlPedido {

	public static void mostrar() {

		
	}

}
