package principal;

import java.io.FileNotFoundException;

import principal.telas.cliente.TelaCliente;

public class Programa {
	public static void main(String[] args) throws FileNotFoundException {
		TelaCliente.mostrarMenu();
	}
}
